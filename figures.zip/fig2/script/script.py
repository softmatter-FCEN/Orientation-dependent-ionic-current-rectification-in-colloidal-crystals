#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  2 13:39:40 2023

@author: santiago
"""

#Librerias
import matplotlib.patches as mpatches
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import pandas as pd
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
import matplotlib.ticker
class OOMFormatter(matplotlib.ticker.ScalarFormatter):
    def __init__(self, order=0, fformat="%1.1f", offset=True, mathText=True):
        self.oom = order
        self.fformat = fformat
        matplotlib.ticker.ScalarFormatter.__init__(self,useOffset=offset,useMathText=mathText)
    def _set_order_of_magnitude(self):
        self.orderOfMagnitude = self.oom
    def _set_format(self, vmin=None, vmax=None):
        self.format = self.fformat
        if self._useMathText:
            self.format = r'$\mathdefault{%s}$' % self.format
import os; import re
import seaborn as sns
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.gridspec as gridspec
import matplotlib.patches as patches
plt.rcParams["mathtext.fontset"]='dejavuserif'
pi = math.pi
#%%
datos_rhocuad = pd.read_excel('../data/data_rho_cuad.xlsx', skiprows=1, engine='openpyxl')
E_rho = datos_rhocuad[datos_rhocuad.columns[0]].to_numpy()
rho_111 = datos_rhocuad[datos_rhocuad.columns[1]].to_numpy()
rho_001 = datos_rhocuad[datos_rhocuad.columns[2]].to_numpy()


datos = pd.read_csv('../data/data_001_Eneg_2D_dir1_neg.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Eneg_110_1_NPneg = datos



datos = pd.read_csv('../data/data_001_Eneg_2D_dir1_neg_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Eneg_110_2_NPneg = datos


datos = pd.read_csv('../data/data_001_Eneg_2D_dir1_pos.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Eneg_110_1_NPpos = datos



datos = pd.read_csv('../data/data_001_Eneg_2D_dir1_pos_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Eneg_110_2_NPpos = datos



datos = pd.read_csv('../data/data_001_Eneg_2D_dir2.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Eneg_1_10 = datos



datos = pd.read_csv('../data/data_001_Epos_2D_dir1_neg.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Epos_110_1_NPneg = datos



datos = pd.read_csv('../data/data_001_Epos_2D_dir1_neg_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Epos_110_2_NPneg = datos



datos = pd.read_csv('../data/data_001_Epos_2D_dir1_pos.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Epos_110_1_NPpos = datos



datos = pd.read_csv('../data/data_001_Epos_2D_dir1_pos_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Epos_110_2_NPpos = datos




datos = pd.read_csv('../data/data_001_Epos_2D_dir2.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E001_Epos_1_10 = datos

#cambio
datos = pd.read_csv('../data/data_111_Eneg_2D_dir1_neg.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Eneg_110_1_NPneg = datos




#cambio
datos = pd.read_csv('../data/data_111_Eneg_2D_dir1_neg_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Eneg_110_2_NPneg = datos


#cambio
datos = pd.read_csv('../data/data_111_Eneg_2D_dir1_pos.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Eneg_110_1_NPpos = datos


#cambio
datos = pd.read_csv('../data/data_111_Eneg_2D_dir1_pos_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Eneg_110_2_NPpos = datos





datos = pd.read_csv('../data/data_111_Eneg_2D_dir2.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Eneg_1_10 = datos




#cambio
datos = pd.read_csv('../data/data_111_Epos_2D_dir1_neg.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Epos_110_1_NPneg = datos





#cambio
datos = pd.read_csv('../data/data_111_Epos_2D_dir1_neg_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Epos_110_2_NPneg = datos



#cambio
datos = pd.read_csv('../data/data_111_Epos_2D_dir1_pos.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Epos_110_1_NPpos = datos





#cambio
datos = pd.read_csv('../data/data_111_Epos_2D_dir1_pos_top.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Epos_110_2_NPpos = datos






datos = pd.read_csv('../data/data_111_Epos_2D_dir2.csv',skiprows=8)
realColumns = ['xy', 'z', 'Cc+ca', 'Cc-ca', 'Cc', 'Ca']
datos.columns = realColumns
E111_Epos_1_10 = datos





#%%
n1 = [0,1,2,3,4,5,6,7,8,9]+[0,1,2,3,4,5,6,7,8,9]+[0,1,2,3,4,5,6,7,8,9]
n10 = [0,0,0,0,0,0,0,0,0,0]+[1,1,1,1,1,1,1,1,1,1]+[2,2,2,2,2,2,2,2,2,2]

#%%
R = 5
aL = 32

def func(data):
    X = data['xy'][:int(len(data['xy'])/300)]*10**9
    Y = data['z'][np.arange(0,len(data['xy']),int(len(data['xy'])/300))]*10**9
    C_neg = (data[data.columns[3]]).to_numpy()/1000
    C_pos = (data[data.columns[3]]).to_numpy()/1000
    
    return X, Y, C_neg, C_pos

X_E001_1_NPneg = func(E001_Eneg_110_1_NPneg)[0]
Y_E001_1_NPneg = func(E001_Eneg_110_1_NPneg)[1]
C_neg_E001_1_NPneg = func(E001_Eneg_110_1_NPneg)[2]
C_pos_E001_1_NPneg = func(E001_Epos_110_1_NPneg)[3]

X_E001_1_NPpos = func(E001_Eneg_110_1_NPpos)[0]
Y_E001_1_NPpos = func(E001_Eneg_110_1_NPpos)[1]
C_neg_E001_1_NPpos = func(E001_Eneg_110_1_NPpos)[2]
C_pos_E001_1_NPpos = func(E001_Epos_110_1_NPpos)[3]

X_E001_2_NPneg = func(E001_Eneg_110_2_NPneg)[0]
Y_E001_2_NPneg = func(E001_Eneg_110_2_NPneg)[1]
C_neg_E001_2_NPneg = func(E001_Eneg_110_2_NPneg)[2]
C_pos_E001_2_NPneg = func(E001_Epos_110_2_NPneg)[3]

X_E001_2_NPpos = func(E001_Eneg_110_2_NPpos)[0]
Y_E001_2_NPpos = func(E001_Eneg_110_2_NPpos)[1]
C_neg_E001_2_NPpos = func(E001_Eneg_110_2_NPpos)[2]
C_pos_E001_2_NPpos = func(E001_Epos_110_2_NPpos)[3]

X_E001_3 = func(E001_Eneg_1_10)[0]
Y_E001_3 = func(E001_Eneg_1_10)[1]
C_neg_E001_3 = func(E001_Eneg_1_10)[2]
C_pos_E001_3 = func(E001_Epos_1_10)[3]

X_E111_1_NPneg = func(E111_Eneg_110_1_NPneg)[0]
Y_E111_1_NPneg = func(E111_Eneg_110_1_NPneg)[1]
C_neg_E111_1_NPneg = func(E111_Eneg_110_1_NPneg)[2]
C_pos_E111_1_NPneg = func(E111_Epos_110_1_NPneg)[3]

X_E111_1_NPpos = func(E111_Eneg_110_1_NPpos)[0]
Y_E111_1_NPpos = func(E111_Eneg_110_1_NPpos)[1]
C_neg_E111_1_NPpos = func(E111_Eneg_110_1_NPpos)[2]
C_pos_E111_1_NPpos = func(E111_Epos_110_1_NPpos)[3]

X_E111_2_NPneg = func(E111_Eneg_110_2_NPneg)[0]
Y_E111_2_NPneg = func(E111_Eneg_110_2_NPneg)[1]
C_neg_E111_2_NPneg = func(E111_Eneg_110_2_NPneg)[2]
C_pos_E111_2_NPneg = func(E111_Epos_110_2_NPneg)[3]

X_E111_2_NPpos = func(E111_Eneg_110_2_NPpos)[0]
Y_E111_2_NPpos = func(E111_Eneg_110_2_NPpos)[1]
C_neg_E111_2_NPpos = func(E111_Eneg_110_2_NPpos)[2]
C_pos_E111_2_NPpos = func(E111_Epos_110_2_NPpos)[3]




X_E111_3 = func(E111_Eneg_1_10)[0]
Y_E111_3 = func(E111_Eneg_1_10)[1]
C_neg_E111_3 = func(E111_Eneg_1_10)[2]
C_pos_E111_3 = func(E111_Epos_1_10)[3]

C1_E001_NPneg = [C_neg_E001_1_NPneg,C_pos_E001_1_NPneg]
C1_E001_NPpos = [C_neg_E001_1_NPpos,C_pos_E001_1_NPpos]
C2_E001_NPneg = [C_neg_E001_2_NPneg,C_pos_E001_2_NPneg]
C2_E001_NPpos = [C_neg_E001_2_NPpos,C_pos_E001_2_NPpos]
C3_E001 = [C_neg_E001_3,C_pos_E001_3]
C1_E111_NPneg = [C_neg_E111_1_NPneg,C_pos_E111_1_NPneg]
C1_E111_NPpos = [C_neg_E111_1_NPpos,C_pos_E111_1_NPpos]
C2_E111_NPneg = [C_neg_E111_2_NPneg,C_pos_E111_2_NPneg]
C2_E111_NPpos = [C_neg_E111_2_NPpos,C_pos_E111_2_NPpos]



C3_E111 = [C_neg_E111_3,C_pos_E111_3]


Fl = 35; Ft = 30

E = np.array([-0.2,0.2])
Efield = []
for i in range(len(E)):
    Efield.append("$"+str("{:.1f}".format(E[i]))+"\ \\text{V/nm}$")
a = -0.12; b = 0.12
aL = 32
cmap = 'bwr'
#cmap = 'viridis'
#a = 0; b = 0.25

#%%
fig = plt.figure(dpi=300, figsize=[34, 8], constrained_layout=True)


gs = gridspec.GridSpec(2, 5, top=0.975, wspace=0.05, hspace=0.05, width_ratios=[25,25,60,25,25])
gs_rho = gridspec.GridSpec(2, 5,left=0.17, top=0.7, wspace=0.35, hspace=0.05, width_ratios=[25,25,60,25,25])

gs_tit = gridspec.GridSpec(2, 5,top=1, wspace=0.1, width_ratios=[25,25,60,25,25])

gs_c = plt.GridSpec(4, 3, right=0.85)
ax_title_1 = fig.add_subplot(gs_tit[0, :2])
ax_title_1.set_title('(001)', fontsize=Fl+2)
ax_title_1.axis('off')  # Ocultar el eje
ax_title_2 = fig.add_subplot(gs_tit[0, 3:])
ax_title_2.set_title('(111)', fontsize=Fl+2)
ax_title_2.axis('off')  # Ocultar el eje

ax0 = fig.add_subplot(gs[0, 0])
ax1 = fig.add_subplot(gs[1, 1])
ax2 = fig.add_subplot(gs[1, 0])
ax3 = fig.add_subplot(gs[0, 1])
ax4 = fig.add_subplot(gs[0, 3])
ax5 = fig.add_subplot(gs[1, 4])
ax6 = fig.add_subplot(gs[1, 3])
ax7 = fig.add_subplot(gs[0, 4])

ax8 = fig.add_subplot(gs_rho[:, 2])
#axc = fig.add_subplot(gs_c[:2, 1])

axes = [ax0,ax1,ax2,ax3,ax4,ax5,ax6,ax7]
ax111_1 = [ax4,ax5]; ax111_2 = [ax6,ax7]
ax001_1 = [ax0,ax1]; ax001_2 = [ax2,ax3]

for ax in [ax0,ax3,ax4,ax7]:
    ax.xaxis.set_label_position('top')
for ax in [ax1,ax3,ax5,ax7]:
    ax.yaxis.set_label_position('right')
    
for i in range(0,len(Efield),1):
    W = []; W2 = []
    W1_NPneg = C1_E001_NPneg[i].reshape(len(Y_E001_1_NPneg), len(X_E001_1_NPneg))
    W2_NPneg = C2_E001_NPneg[i].reshape(len(Y_E001_2_NPneg), len(X_E001_2_NPneg))
    W3 = C3_E001[i].reshape(len(Y_E001_3), len(X_E001_3))
    W1_NPpos = C1_E001_NPpos[i].reshape(len(Y_E001_1_NPpos), len(X_E001_1_NPpos))
    W2_NPpos = C2_E001_NPpos[i].reshape(len(Y_E001_2_NPpos), len(X_E001_2_NPpos))
    
    W4_NPneg = C1_E111_NPneg[i].reshape(len(Y_E111_1_NPneg), len(X_E111_1_NPneg))
    W5_NPneg = C2_E111_NPneg[i].reshape(len(Y_E111_2_NPneg), len(X_E111_2_NPneg))
    W6 = C3_E111[i].reshape(len(Y_E111_3), len(X_E111_3))
    W4_NPpos = C1_E111_NPpos[i].reshape(len(Y_E111_1_NPpos), len(X_E111_1_NPpos))
    W5_NPpos = C2_E111_NPpos[i].reshape(len(Y_E111_2_NPpos), len(X_E111_2_NPpos))
    
    for j in range(-3,3,1): #-231
        for k in range(-3,3,1): #-221

           ax001_1[i].contourf(X_E001_1_NPneg+j*aL/2**0.5,Y_E001_1_NPneg+k*aL,W1_NPneg,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax001_1[i].contourf(X_E001_2_NPneg+j*aL/2**0.5,
                               Y_E001_2_NPneg+k*aL,W2_NPneg,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax001_1[i].contourf(X_E001_1_NPpos+j*aL/2**0.5+aL/8**0.5,
                               Y_E001_1_NPpos+k*aL+aL/2,W1_NPpos,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax001_1[i].contourf(X_E001_2_NPpos+j*aL/2**0.5+aL/8**0.5,
                               Y_E001_2_NPpos+k*aL+aL/2,W2_NPpos,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax001_2[i].contourf(X_E001_3+j*aL/2**0.5,Y_E001_3+k*aL,W3,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           
           ax111_1[i].contourf(X_E111_1_NPneg+j*aL/2**0.5,Y_E111_1_NPneg+k*aL,W4_NPneg,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax111_1[i].contourf(X_E111_2_NPneg+j*aL/2**0.5,Y_E111_2_NPneg+k*aL,W5_NPneg,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax111_1[i].contourf(X_E111_1_NPpos+j*aL/2**0.5+aL/8**0.5,
                               Y_E111_1_NPpos+k*aL+aL/2,W4_NPpos,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax111_1[i].contourf(X_E111_2_NPpos+j*aL/2**0.5+aL/8**0.5,
                               Y_E111_2_NPpos+k*aL+aL/2,W5_NPpos,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')
           ax111_2[i].contourf(X_E111_3+j*aL/2**0.5,Y_E111_3+k*aL,W6,
                                  levels=np.linspace(a,b, 100),
                                  cmap=cmap,vmin=a,vmax=b,extend='both')

    ax111_1[i].set_xlabel(Efield[i],fontsize=Fl)
    ax111_2[i].set_xlabel(Efield[i],fontsize=Fl)
    ax001_1[i].set_xlabel(Efield[i],fontsize=Fl)
    ax001_2[i].set_xlabel(Efield[i],fontsize=Fl)

#    divider = make_axes_locatable(axc)

    # color_bar = fig.colorbar(mappable, orientation='horizontal', 
    #                           ticks=np.linspace(-0.1,0.1,3),extend="both")
    # color_bar.ax.tick_params(labelsize=25)
    # color_bar.set_label(r"$\Delta \rho \ (nm^{-3})$",fontsize=36)


for ax in axes:
    
    
    ax.set_xlim(-aL/2,aL*3/2)
    ax.set_ylim(-aL/2,aL*3/2)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.tick_params(labelsize = Ft, direction='in', length = 10, pad=10)

ax0.set_ylabel('$x+y$',fontsize=Fl); ax2.set_ylabel('$x-y$',fontsize=Fl)
ax5.set_ylabel('$x+y$',fontsize=Fl); ax7.set_ylabel('$x-y$',fontsize=Fl)
ax4.set_ylabel('$x+y$',fontsize=Fl); ax6.set_ylabel('$x-y$',fontsize=Fl)
ax1.set_ylabel('$x+y$',fontsize=Fl); ax3.set_ylabel('$x-y$',fontsize=Fl)


#     ax.set_xlim(-aL*1/2,aL*3/2)
#     ax.set_ylim(-aL*1/2,aL*3/2)
#     ax.set_xticks([])
#     ax.set_yticks([])
#     ax.tick_params(labelsize = Ft, direction='in', length = 10, pad=10)
    
# a0L=-1/32*aL
# a1L=2*aL+a0L

# ax001_2[0].set_xlim(a0L,a1L)
# ax001_2[0].set_ylim(a0L,a1L)

# ax001_2[1].set_xlim(a0L,a1L)
# ax001_2[1].set_ylim(a0L,a1L)


# a0L=-12/32*aL
# a1L=2*aL+a0L
# ax111_1[1].set_xlim(a0L,a1L)

# a0L=-6/32*aL
# a1L=2*aL+a0L
# ax111_1[1].set_ylim(a1L,a0L)

# ax0.set_ylabel('$x+y$',fontsize=Fl); ax2.set_ylabel('$x-y$',fontsize=Fl)
# ax5.set_ylabel('$x+y$',fontsize=Fl); ax7.set_ylabel('$x-y$',fontsize=Fl)
# ax4.set_ylabel('$x+y$',fontsize=Fl); ax6.set_ylabel('$x-y$',fontsize=Fl)
# ax1.set_ylabel('$x+y$',fontsize=Fl); ax3.set_ylabel('$x-y$',fontsize=Fl)


ax8.plot(E_rho,rho_111,'-o',markersize=10,lw=3,label='$\mathbf{E^{ext}}$ || [111]',zorder=11)
ax8.plot(E_rho,rho_001,'-o',markersize=10,lw=3,label='$\mathbf{E^{ext}}$ || [001]',zorder=10)
ax8.set_xlabel(r"$E^{\text{ext}}\ \text{(V/nm)}$",fontsize=Fl)
ax8.set_ylabel(r" $\langle (\rho_+ + \rho_-)^2 \rangle (nm^{-6})$ ",fontsize=Fl)
ax8.set_xticks(np.arange(-0.3,0.3,0.1))
ax8.set_xlim(xmin=-0.225,xmax=0.225)
#ax8.set_yticks(np.arange(-45,60,15))
ax8.set_ylim(ymin=0.008,ymax=0.018)
ax8.xaxis.set_major_formatter(FormatStrFormatter('%1.1f'))
ax8.yaxis.set_major_formatter(OOMFormatter(-2,'%1.1f'))
ax8.tick_params(labelsize = Ft, direction='in', length = 10, pad=10)
ax8.legend(fontsize=Ft-3, loc='upper left')
ax8.axvline(x=0,ls='--',c='darkgray',zorder=-5, lw=2)


fig.savefig('../fig/fig2.png', format="png", dpi=300, bbox_inches='tight')
plt.close("all")
