# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 13:26:49 2024

@author: santi
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from mpl_toolkits.mplot3d import Axes3D
import seaborn as sns
from scipy.interpolate import griddata
import matplotlib.gridspec as gridspec
import os

plt.rcParams["mathtext.fontset"] = 'dejavuserif'

pi = math.pi

data_wurt = pd.read_excel('../data/data_wurtzita_aL32.xlsx', engine='openpyxl')

phi_wurt = data_wurt[data_wurt.columns[1]].to_numpy() * pi
theta_wurt = data_wurt[data_wurt.columns[2]].to_numpy() * pi
Jpos_wurt = data_wurt[data_wurt.columns[7]].to_numpy()
Jneg_wurt = data_wurt[data_wurt.columns[3]].to_numpy()

n_coef_wurt = np.empty(len(Jpos_wurt))
for i in range(len(Jpos_wurt)):
    if abs(Jpos_wurt[i] / Jneg_wurt[i]) > 1:
        n_coef_wurt[i] = np.log10(abs(Jpos_wurt[i] / Jneg_wurt[i])-1)
    else:
        n_coef_wurt[i] = np.log10(abs(Jneg_wurt[i] / Jpos_wurt[i])-1)

n_coef_wurt_lin = np.empty(len(Jpos_wurt))
for i in range(len(Jpos_wurt)):
    if abs(Jpos_wurt[i] / Jneg_wurt[i]) > 1:
        n_coef_wurt_lin[i] = abs(Jpos_wurt[i] / Jneg_wurt[i])
    else:
        n_coef_wurt_lin[i] = abs(Jneg_wurt[i] / Jpos_wurt[i])

        
a1 = -3; b1 = -.5; Fl = 36; Ft = 30
a2 = 1; b2 = 1.5
sns.color_palette("gnuplot")
sns.set_style("ticks")
sns.set_context("paper")
sns.set(rc={'axes.facecolor': 'white', 'figure.facecolor': 'white', 
            'axes.edgecolor': 'black', 'xtick.bottom': True, 'ytick.left': True})
results_dir = "../fig/."

fig = plt.figure(dpi=300, figsize=[20, 10], constrained_layout=True)

gs_a = gridspec.GridSpec(11, 4, wspace=0.25, width_ratios=[100,5,100,5])
gs_b = gridspec.GridSpec(11, 4, wspace=0.25, width_ratios=[100,5,100,5])
gs_c = gridspec.GridSpec(11, 4, right=0.85, wspace=0.5, width_ratios=[100,5,100,5])
gs_d = gridspec.GridSpec(11, 4, right=0.85, wspace=0.5, width_ratios=[100,5,100,5])

ax0 = fig.add_subplot(gs_a[:11, 0], projection='3d')
ax1 = fig.add_subplot(gs_b[:11, 2], projection='3d')
axc0 = fig.add_subplot(gs_c[1:10, 1])
axc1 = fig.add_subplot(gs_d[1:10, 3])
axc0.text(-24, 1, 'a)', transform = axc0.transAxes, size = Fl+2, style='italic')
axc1.text(-22.5, 1, 'b)', transform = axc1.transAxes, size = Fl+2, style='italic')

ax2 = fig.add_subplot(gs_a[:11, 0], projection='3d', computed_zorder=False)
ax3 = fig.add_subplot(gs_b[:11, 2], projection='3d', computed_zorder=False)
ax2.patch.set_alpha(0)
ax3.patch.set_alpha(0)

for j in [1,0]:
    for k in [-1,1]:
        Phi_wurt = np.linspace(min(phi_wurt), max(phi_wurt), 200) * k
        Theta_wurt = np.linspace(min(theta_wurt), max(theta_wurt), 200) + j * pi
        Phi_grid_wurt, Theta_grid_wurt = np.meshgrid(Phi_wurt, Theta_wurt)
               
        Wi_wurt_lin = griddata((phi_wurt * k, theta_wurt + j * pi), n_coef_wurt_lin, (Phi_grid_wurt, Theta_grid_wurt), method='cubic')
        Wi_wurt_log = griddata((phi_wurt * k, theta_wurt + j * pi), n_coef_wurt, (Phi_grid_wurt, Theta_grid_wurt), method='cubic')
    
        r = 1
        x_fine_wurt = r * np.sin(Theta_grid_wurt) * np.cos(Phi_grid_wurt)
        y_fine_wurt = r * np.sin(Theta_grid_wurt) * np.sin(Phi_grid_wurt)
        z_fine_wurt = r * np.cos(Theta_grid_wurt)

        cmap_set = sns.cubehelix_palette(start=0.7, rot=-0.9, as_cmap=True, gamma=1.1,
                                         reverse=True, hue=1.7, dark=0.1, light=0.8)
        
        cmap_set = sns.color_palette('gnuplot', as_cmap=True)
        norm_wurt_lin = plt.Normalize(a2, b2)
        colors_wurt = cmap_set(norm_wurt_lin(Wi_wurt_lin))
        
        norm_wurt_log = plt.Normalize(a1, b1)
        colors_wurt_log = cmap_set(norm_wurt_log(Wi_wurt_log))
        ax1.plot_surface(x_fine_wurt, y_fine_wurt, z_fine_wurt, facecolors=colors_wurt_log, 
                         rstride=1, cstride=1, linewidth=0, antialiased=False, shade=False)
        
        ax0.plot_surface(x_fine_wurt, y_fine_wurt, z_fine_wurt, facecolors=colors_wurt, 
                         rstride=1, cstride=1, linewidth=0, antialiased=False, shade=False)

mappable_lin = plt.cm.ScalarMappable(cmap=cmap_set, norm=norm_wurt_lin)
mappable_lin.set_array(Wi_wurt_lin)
color_bar = fig.colorbar(mappable_lin, cax=axc0, orientation='vertical', 
                         ticks=np.linspace(a2, b2, 6), extend="both")
color_bar.ax.tick_params(labelsize=Ft)
color_bar.set_label('$\\alpha$', fontsize=Fl)

mappable_log = plt.cm.ScalarMappable(cmap=cmap_set, norm=norm_wurt_log)
mappable_log.set_array(Wi_wurt_log)
color_bar = fig.colorbar(mappable_log, cax=axc1, orientation='vertical', 
                         ticks=[0,-1,-2,-3],  extend="both")
color_bar.ax.tick_params(labelsize=Ft)
color_bar.set_ticklabels([1,1.1,1.01,1.001])
color_bar.set_label('$\\alpha_{CR}$', fontsize=Fl)
  # \\alpha  |\\bar{J}_{-i}/\\bar{J}_{i}|  
for ax in [ax2,ax3]:      

# Dibujar los quivers en ax2
    ax.quiver(-np.cos(pi/3), -np.sin(pi/3), 0, -0.25, -0.25, 0, color="black", lw=6, arrow_length_ratio=0.5, zorder=6)
    ax.quiver(1, 0, 0, 0.7, 0, 0, color="black", lw=6, arrow_length_ratio=0.35, zorder=5)
    ax.quiver(0, 0, 1, 0, 0, 0.3, color="black", lw=6, arrow_length_ratio=0.55, zorder=7)
    ax.text(1.45, 0, 0.125, '$\\vec{b}$', color='black', fontsize=Fl+4)
    ax.text(-np.cos(pi/3)-0.025**0.5, -np.sin(pi/3)-0.025**0.5, 0.125, '$\\vec{a}$', color='black', fontsize=Fl+4)
    ax.text(-0.15, -0.15, 1.1, '$\\vec{c}$', color='black', fontsize=Fl+4)

for ax in [ax0,ax1,ax2,ax3]:
    ax.set_aspect('equal')
    ax.set_xlim([-1.2, 1.2])
    ax.set_ylim([-1.2, 1.2])
    ax.set_zlim([-1.2, 1.2])
    ax.grid(False)
    ax.axis('off')
    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    ax.xaxis.set_ticks([])
    ax.yaxis.set_ticks([])
    ax.zaxis.set_ticks([])
    ax.get_proj = lambda: np.dot(Axes3D.get_proj(ax), np.diag([1.5, 1.5, 1.5, 1]))
    ax.set_aspect('equal')
    ax.view_init(25, -40)
    
sample_file_name = "fig3.png"
fig.savefig(os.path.join(results_dir, sample_file_name), format="png", dpi=300, bbox_inches='tight')
plt.show()
