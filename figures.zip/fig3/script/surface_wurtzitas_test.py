# -*- coding: utf-8 -*-
"""
Created on Sun Jun  2 19:17:41 2024

@author: Santiago
"""

import numpy as np
import pandas as pd
import math
from mayavi import mlab
from scipy.interpolate import griddata

# Definir constantes
pi = math.pi
a = 1.00
b = 1.50
Fl = 36  # Tamaño de la fuente
Ft = 30

# Cargar datos
data_wurt = pd.read_excel('../data/data_wurtzita_aL32.xlsx', engine='openpyxl')
phi_wurt = data_wurt[data_wurt.columns[1]].to_numpy() * pi
theta_wurt = data_wurt[data_wurt.columns[2]].to_numpy() * pi
Jpos_wurt = data_wurt[data_wurt.columns[7]].to_numpy()
Jneg_wurt = data_wurt[data_wurt.columns[3]].to_numpy()

# Calcular el coeficiente n_coef
n_coef_wurt = np.empty(len(Jpos_wurt))
for i in range(len(Jpos_wurt)):
    if abs(Jpos_wurt[i] / Jneg_wurt[i]) > 1:
        n_coef_wurt[i] = abs(Jpos_wurt[i] / Jneg_wurt[i])
    else:
        n_coef_wurt[i] = abs(Jneg_wurt[i] / Jpos_wurt[i])

# Crear la figura en mayavi
mlab.figure(size=(800, 600), bgcolor=(1, 1, 1))

for j in range(0, 2):
    for k in range(-1, 2, 2):
        # Definir los límites y el espacio de interpolación
        Phi_wurt = np.linspace(min(phi_wurt), max(phi_wurt), 200) * k
        Theta_wurt = np.linspace(min(theta_wurt), max(theta_wurt), 200) + j * pi
        
        # Crear una malla fina para interpolar
        Phi_grid_wurt, Theta_grid_wurt = np.meshgrid(Phi_wurt, Theta_wurt)
        
        # Interpolar los valores de n_coef en la nueva malla
        Wi_wurt = griddata((phi_wurt * k, theta_wurt + j * pi), n_coef_wurt, 
                           (Phi_grid_wurt, Theta_grid_wurt), method='cubic')
        
        # Convertir a coordenadas cartesianas para la esfera
        r = 1  # Radio de la esfera
        x_fine_wurt = r * np.sin(Theta_grid_wurt) * np.cos(Phi_grid_wurt)
        y_fine_wurt = r * np.sin(Theta_grid_wurt) * np.sin(Phi_grid_wurt)
        z_fine_wurt = r * np.cos(Theta_grid_wurt)
    
        # Graficar la superficie en la esfera con color basado en Wi
        surface = mlab.mesh(x_fine_wurt, y_fine_wurt, z_fine_wurt, scalars=Wi_wurt, colormap='viridis')

        # Añadir las flechas de quiver para ejes x, y, z
        quiver_len = 1.0  # Longitud de las flechas
        mlab.quiver3d([1], [0], [0], [0.5], [0], [0], scale_factor=quiver_len, color=(1, 0, 0), mode='arrow')  # Eje x
        mlab.quiver3d([0], [1], [0], [0], [0.5], [0], scale_factor=quiver_len, color=(0, 1, 0), mode='arrow')  # Eje y
        mlab.quiver3d([0], [0], [1], [0], [0], [0.5], scale_factor=quiver_len, color=(0, 0, 1), mode='arrow')  # Eje z

# Configurar la barra de colores
colorbar = mlab.colorbar(object=surface,title="|J-/J+|", orientation='vertical')
colorbar.label_text_property.color = (0, 0, 0)
colorbar.title_text_property.color = (0, 0, 0)

# Ajustes de los ejes
mlab.view(azimuth=30, elevation=25, distance=4)

# Mostrar la figura
mlab.show()