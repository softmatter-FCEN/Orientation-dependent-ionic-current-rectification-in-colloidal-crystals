# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 13:16:18 2024

@author: santi
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from mpl_toolkits.mplot3d import Axes3D
import seaborn as sns
from scipy.interpolate import griddata
import matplotlib.gridspec as gridspec
import os

plt.rcParams["mathtext.fontset"] = 'dejavuserif'

pi = math.pi
#%%

data_wurt = pd.read_excel('../data/data_wurtzita_aL32.xlsx', engine='openpyxl')
data_aucl = pd.read_excel('../data/AuCl_Q0.1_TOPLOT.xlsx')

phi_wurt = data_wurt[data_wurt.columns[1]].to_numpy() * pi
theta_wurt = data_wurt[data_wurt.columns[2]].to_numpy() * pi
Jpos_wurt = data_wurt[data_wurt.columns[7]].to_numpy()
Jneg_wurt = data_wurt[data_wurt.columns[3]].to_numpy()

phi_aucl = data_aucl[data_aucl.columns[0]].to_numpy()
theta_aucl = data_aucl[data_aucl.columns[1]].to_numpy()
Jpos_aucl = data_aucl[data_aucl.columns[2]].to_numpy()
Jneg_aucl = data_aucl[data_aucl.columns[3]].to_numpy()

n_coef_wurt = np.empty(len(Jpos_wurt))
for i in range(len(Jpos_wurt)):
    if abs(Jpos_wurt[i] / Jneg_wurt[i]) > 1:
        n_coef_wurt[i] = abs(Jpos_wurt[i] / Jneg_wurt[i])
    else:
        n_coef_wurt[i] = abs(Jneg_wurt[i] / Jpos_wurt[i])

n_coef_aucl = np.empty(len(Jpos_aucl))
for i in range(len(Jpos_aucl)):
    if abs(Jpos_aucl[i] / Jneg_aucl[i]) > 1:
        n_coef_aucl[i] = abs(Jpos_aucl[i] / Jneg_aucl[i])
    else:
        n_coef_aucl[i] = abs(Jneg_aucl[i] / Jpos_aucl[i])

sns.color_palette("colorblind")
sns.set_style("ticks")
sns.set_context("paper")
sns.set(rc={'axes.facecolor': 'white', 'figure.facecolor': 'white', 
            'axes.edgecolor': 'black', 'xtick.bottom': True, 'ytick.left': True})
results_dir = "../fig/."        
a_lin = 1; b1_lin = 1.5; b2_lin = 1.01; Fl = 36; Ft = 30 
fig = plt.figure(dpi=300, figsize=[10, 20], constrained_layout=True)

gs_a = gridspec.GridSpec(21, 2, left=0, hspace=0, wspace=0, width_ratios=[100, 5])
gs_c = gridspec.GridSpec(21, 2, wspace=0.2, width_ratios=[100, 5])

ax0 = fig.add_subplot(gs_a[:11, 0], projection='3d')
ax1 = fig.add_subplot(gs_a[10:, 0], projection='3d')
axc0 = fig.add_subplot(gs_c[1:10, 1])
axc1 = fig.add_subplot(gs_c[11:20, 1])
axc0.text(-25, 1.1, 'a)', transform = axc0.transAxes, size = Fl+2, style='italic')
axc1.text(-25, 1.1, 'b)', transform = axc1.transAxes, size = Fl+2, style='italic')

ax2 = fig.add_subplot(gs_a[:11, 0], projection='3d', computed_zorder=False)
ax3 = fig.add_subplot(gs_a[10:, 0], projection='3d', computed_zorder=False)
ax2.patch.set_alpha(0)
ax3.patch.set_alpha(0)

for j in [1,0]:
    for k in [-1,1]:
        Phi_wurt = np.linspace(min(phi_wurt), max(phi_wurt), 200) * k
        Theta_wurt = np.linspace(min(theta_wurt), max(theta_wurt), 200) + j * pi
        Phi_grid_wurt, Theta_grid_wurt = np.meshgrid(Phi_wurt, Theta_wurt)
               
        Wi_wurt = griddata((phi_wurt * k, theta_wurt + j * pi), n_coef_wurt, (Phi_grid_wurt, Theta_grid_wurt), method='cubic')
    
        r = 1
        x_fine_wurt = r * np.sin(Theta_grid_wurt) * np.cos(Phi_grid_wurt)
        y_fine_wurt = r * np.sin(Theta_grid_wurt) * np.sin(Phi_grid_wurt)
        z_fine_wurt = r * np.cos(Theta_grid_wurt)

        
        cmap_set = sns.color_palette('viridis_r', as_cmap=True)
        norm_wurt = plt.Normalize(a_lin, b1_lin)
        colors_wurt = cmap_set(norm_wurt(Wi_wurt))
        ax0.plot_surface(x_fine_wurt, y_fine_wurt, z_fine_wurt, facecolors=colors_wurt, 
                         rstride=1, cstride=1, linewidth=0, antialiased=False, shade=False)

mappable = plt.cm.ScalarMappable(cmap=cmap_set, norm=norm_wurt)
mappable.set_array(Wi_wurt)
color_bar = fig.colorbar(mappable, cax=axc0, orientation='vertical', 
                         ticks=np.linspace(a_lin, b1_lin, 6), extend="both")
color_bar.ax.tick_params(labelsize=Ft)
color_bar.set_label('$|\\bar{J}_{-i}/\\bar{J}_{i}|$', fontsize=Fl)

for j in [1,0]:
    for k in [-1,1]:
        Phi_aucl = np.linspace(min(phi_aucl), max(phi_aucl), 200) * k
        Theta_aucl = np.linspace(min(theta_aucl), max(theta_aucl), 200) + j * pi
        Phi_grid_aucl, Theta_grid_aucl = np.meshgrid(Phi_aucl, Theta_aucl)
               
        Wi_aucl = griddata((phi_aucl * k, theta_aucl + j * pi), n_coef_aucl, (Phi_grid_aucl, Theta_grid_aucl), method='cubic')
    
        r = 1
        x_fine_aucl = r * np.sin(Theta_grid_aucl) * np.cos(Phi_grid_aucl)
        y_fine_aucl = r * np.sin(Theta_grid_aucl) * np.sin(Phi_grid_aucl)
        z_fine_aucl = r * np.cos(Theta_grid_aucl)

        cmap_set = sns.color_palette('viridis_r', as_cmap=True)
        
        norm_aucl = plt.Normalize(a_lin, b2_lin)
        colors_aucl = cmap_set(norm_aucl(Wi_aucl))

        ax1.plot_surface(x_fine_aucl, y_fine_aucl, z_fine_aucl, facecolors=colors_aucl, 
                         rstride=1, cstride=1, linewidth=0, antialiased=False, shade=False)

mappable = plt.cm.ScalarMappable(cmap=cmap_set, norm=norm_aucl)
mappable.set_array(Wi_aucl)
color_bar = fig.colorbar(mappable, cax=axc1, orientation='vertical', 
                         ticks=np.linspace(a_lin, b2_lin, 6), extend="both")
color_bar.ax.tick_params(labelsize=Ft)
color_bar.set_label('$|\\bar{J}_{-i}/\\bar{J}_{i}|$', fontsize=Fl)
  
for ax in [ax2,ax3]:      

# Dibujar los quivers en ax2
    ax.quiver(1.0, 0, 0, 0.9, 0, 0, color="black", lw=6, arrow_length_ratio=0.2, zorder=5)
    ax.quiver(0, 1, 0, 0, 0.4, 0, color="black", lw=6, arrow_length_ratio=0.4, zorder=6)
    ax.quiver(0, 0, 1, 0, 0, 0.3, color="black", lw=6, arrow_length_ratio=0.6, zorder=7)
    ax.text(1.85, 0, 0.15, '$x$', color='black', fontsize=Fl+4)
    ax.text(0, 1.15, 0.1, '$y$', color='black', fontsize=Fl+4)
    ax.text(0.15, 0.15, 1.2, '$z$', color='black', fontsize=Fl+4)

for ax in [ax0,ax1,ax2,ax3]:
    ax.set_aspect('equal')
    ax.set_xlim([-1.2, 1.2])
    ax.set_ylim([-1.2, 1.2])
    ax.set_zlim([-1.2, 1.2])
    ax.grid(False)
    ax.axis('off')
    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    ax.xaxis.set_ticks([])
    ax.yaxis.set_ticks([])
    ax.zaxis.set_ticks([])
    ax.get_proj = lambda: np.dot(Axes3D.get_proj(ax), np.diag([1.5, 1.5, 1.5, 1]))
    ax.set_aspect('equal')
    ax.view_init(25, 30)
    
sample_file_name = "fig3_lineal.png"
fig.savefig(os.path.join(results_dir, sample_file_name), format="png", dpi=300, bbox_inches='tight')
plt.show()