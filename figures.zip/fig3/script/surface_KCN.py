# -*- coding: utf-8 -*-
"""
Created on Sun Jun  2 19:17:41 2024

@author: Santiago
"""

#Librerias
import matplotlib.patches as mpatches
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
import os; import re
import seaborn as sns
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.patches as patches
plt.rcParams["mathtext.fontset"]='dejavuserif'
pi = math.pi

#%%
data = pd.read_excel('../data/AuCl_Q0.1_TOPLOT.xlsx')

theta = data[data.columns[1]].to_numpy()
phi = data[data.columns[0]].to_numpy()
Jpos = data[data.columns[2]].to_numpy()
Jneg = data[data.columns[3]].to_numpy()

n_coef = np.empty(len(Jpos))
for i in range(len(Jpos)):
    if abs(Jpos[i]/Jneg[i])>1:
        n_coef[i] = np.log(abs(Jpos[i]/Jneg[i])-1)
    else:
        n_coef[i] = np.log(abs(Jneg[i]/Jpos[i])-1)
        
a = -7; b = -2

X = np.arange(0,max(theta)+0.10,0.1)
Y = np.arange(0,max(phi)+0.10,0.1)
W = n_coef.reshape(len(X), len(Y)).transpose()

fig = plt.figure(dpi=300, figsize=[12, 11], constrained_layout=True)
gs = plt.GridSpec(1, 2, left=0.1, width_ratios=[100,5])
gs_c = plt.GridSpec(1, 2, right=0.85, width_ratios=[100,5])
ax = fig.add_subplot(gs[0, 0])
axc = fig.add_subplot(gs_c[:2, 1])
scatter = ax.contourf(X,Y,W,levels=np.linspace(a,b, 100),cmap="viridis_r",vmin=a,vmax=b,extend='both')

ax.set_xlabel('$\\theta/\\pi\ rad$',fontsize=30)
ax.set_ylabel('$\\phi/\\pi\ rad$',fontsize=30)
ax.set_xlim(0,2); ax.set_ylim(0,0.5)
ax.tick_params(axis='y', labelsize=26, pad=10)
ax.tick_params(axis='x', labelsize=26, pad=10)
divider = make_axes_locatable(axc)
color_bar = fig.colorbar(scatter, cax=axc, orientation='vertical', 
                         ticks=np.linspace(a,b,6),extend="both")
color_bar.ax.tick_params(labelsize=30)
color_bar.set_label('$LN(|J_{-i}/J_{i}|-1)$',fontsize=36)
#ax.axhline(np.arccos(1/3**0.5)/pi,ls='--',c='white',lw=2)
#ax.axvline(0.25,ls='--',c='white',lw=2)
ax.tick_params(axis='y', which='both', direction='out', length=12, left=True)
ax.tick_params(axis='x', which='both', direction='out', length=12, bottom=True)
ax.yaxis.set_minor_locator(AutoMinorLocator(2))
ax.xaxis.set_minor_locator(AutoMinorLocator(2))
ax.tick_params(which='minor', length=8, color='k')
ax.set_title('$Wurtzita\ aL=32$ nm', fontsize=36)
fig.savefig('../fig/surface KCN C8.png',format='png', dpi=300, bbox_inches='tight')
plt.show()

#%%
from scipy.interpolate import griddata

# Extraer phi, theta, Jpos y Jneg
phi = data[data.columns[1]].to_numpy()*pi
theta = data[data.columns[2]].to_numpy()*pi
Jpos = data[data.columns[7]].to_numpy()
Jneg = data[data.columns[3]].to_numpy()

# Calcular el coeficiente n_coef
n_coef = np.empty(len(Jpos))
for i in range(len(Jpos)):
    if abs(Jpos[i] / Jneg[i]) > 1:
        n_coef[i] = abs(Jpos[i] / Jneg[i])
    else:
        n_coef[i] = abs(Jneg[i] / Jpos[i])

fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111, projection='3d')
for j in range(0,2):
    for k in range(-1,2,2):
        # Definir los límites y el espacio de interpolación
        Phi = np.linspace(min(phi), max(phi), 100)*k
        Theta = np.linspace(min(theta), max(theta), 100)+j*pi
        # Crear una malla fina para interpolar
        Phi_grid, Theta_grid = np.meshgrid(Phi, Theta)
               
        # Interpolar los valores de W en la nueva malla
        Wi = griddata((phi*k, theta+j*pi), n_coef, (Phi_grid, Theta_grid), method='cubic')
    
        # Convertir a coordenadas cartesianas para la esfera
        r = 1  # Radio de la esfera
        x_fine = r * np.sin(Theta_grid) * np.cos(Phi_grid)
        y_fine = r * np.sin(Theta_grid) * np.sin(Phi_grid)
        z_fine = r * np.cos(Theta_grid)

        # Normalizar Wi para usarlo en la función de color
        norm = plt.Normalize(a, b)
        colors = plt.cm.viridis(norm(Wi))

        # Graficar la superficie en la esfera con color basado en Wi
        ax.plot_surface(x_fine, y_fine, z_fine, facecolors=colors, rstride=1, 
                        cstride=1, linewidth=0, antialiased=False, shade=False)
        # Añadir una barra de colores
mappable = plt.cm.ScalarMappable(cmap=plt.cm.viridis, norm=norm)
mappable.set_array(Wi)
fig.colorbar(mappable, ax=ax, shrink=0.5, aspect=10)

plt.show()