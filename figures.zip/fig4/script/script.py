# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 13:26:49 2024

@author: santi
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from mpl_toolkits.mplot3d import Axes3D
import seaborn as sns
from scipy.interpolate import griddata
import matplotlib.gridspec as gridspec
import os

plt.rcParams["mathtext.fontset"] = 'dejavuserif'

pi = math.pi

data_aucl = pd.read_excel('../data/AuCl_Q0.1_TOPLOT.xlsx')
data_aucl_2 = pd.read_excel('../data/AuCl_0.175_TOPLOT.xlsx')

phi_aucl = data_aucl[data_aucl.columns[0]].to_numpy()
theta_aucl = data_aucl[data_aucl.columns[1]].to_numpy()
Jpos_aucl = data_aucl[data_aucl.columns[2]].to_numpy()
Jneg_aucl = data_aucl[data_aucl.columns[3]].to_numpy()

n_coef_aucl = np.empty(len(Jpos_aucl))
for i in range(len(Jpos_aucl)):
    if abs(Jpos_aucl[i] / Jneg_aucl[i]) > 1:
        n_coef_aucl[i] = np.log10(abs(Jpos_aucl[i] / Jneg_aucl[i])-1)
    else:
        n_coef_aucl[i] = np.log10(abs(Jneg_aucl[i] / Jpos_aucl[i])-1)
        
phi_aucl_2 = data_aucl_2[data_aucl_2.columns[0]].to_numpy()
theta_aucl_2 = data_aucl_2[data_aucl_2.columns[1]].to_numpy()
Jpos_aucl_2 = data_aucl_2[data_aucl_2.columns[2]].to_numpy()
Jneg_aucl_2 = data_aucl_2[data_aucl_2.columns[3]].to_numpy()

n_coef_aucl_2 = np.empty(len(Jpos_aucl_2))
for i in range(len(Jpos_aucl_2)):
    if abs(Jpos_aucl_2[i] / Jneg_aucl_2[i]) > 1:
        n_coef_aucl_2[i] = np.log10(abs(Jpos_aucl_2[i] / Jneg_aucl_2[i])-1)
    else:
        n_coef_aucl_2[i] = np.log10(abs(Jneg_aucl_2[i] / Jpos_aucl_2[i])-1)
        
a1 = -4; b1 = -1; Fl = 36; Ft = 30
a2 = -4; b2 = -1
sns.color_palette("gnuplot")
sns.set_style("ticks")
sns.set_context("paper")
sns.set(rc={'axes.facecolor': 'white', 'figure.facecolor': 'white', 
            'axes.edgecolor': 'black', 'xtick.bottom': True, 'ytick.left': True})
results_dir = "../fig/."

fig = plt.figure(dpi=300, figsize=[20, 10], constrained_layout=True)

gs_a = gridspec.GridSpec(11, 4, wspace=0.25, width_ratios=[100,5,100,5])
gs_b = gridspec.GridSpec(11, 4, wspace=0.25, width_ratios=[100,5,100,5])
gs_c = gridspec.GridSpec(11, 4, right=0.85, wspace=0.5, width_ratios=[100,5,100,5])
gs_d = gridspec.GridSpec(11, 4, right=0.85, wspace=0.5, width_ratios=[100,5,100,5])

ax0 = fig.add_subplot(gs_a[:11, 0], projection='3d')
ax1 = fig.add_subplot(gs_b[:11, 2], projection='3d')
axc0 = fig.add_subplot(gs_c[1:10, 1])
axc1 = fig.add_subplot(gs_d[1:10, 3])
axc0.text(-24, 1, 'a)', transform = axc0.transAxes, size = Fl+2, style='italic')
axc1.text(-22.5, 1, 'b)', transform = axc1.transAxes, size = Fl+2, style='italic')

axc0.text(-12, 0, '|$\mathbf{E}^{\\text{ext}}$|=0.2 V/nm', transform = axc0.transAxes, 
          size = Fl, ha = 'center')
axc1.text(-11.25, 0, '|$\mathbf{E}^{\\text{ext}}$|=0.4 V/nm', transform = axc1.transAxes, 
          size = Fl, ha = 'center')


ax2 = fig.add_subplot(gs_a[:11, 0], projection='3d', computed_zorder=False)
ax3 = fig.add_subplot(gs_b[:11, 2], projection='3d', computed_zorder=False)
ax2.patch.set_alpha(0)
ax3.patch.set_alpha(0)

for j in [1,0]:
    for k in [-1,1]:
        Phi_aucl_2 = np.linspace(min(phi_aucl_2), max(phi_aucl_2), 200)*k
        Theta_aucl_2 = np.linspace(min(theta_aucl_2), max(theta_aucl_2), 200) + j * pi
        Phi_grid_aucl_2, Theta_grid_aucl_2 = np.meshgrid(Phi_aucl_2, Theta_aucl_2)
               
        Wi_aucl_2 = griddata((phi_aucl_2 * k, theta_aucl_2 + j * pi), n_coef_aucl_2, (Phi_grid_aucl_2, Theta_grid_aucl_2), method='cubic')
    
        r = 1
        x_fine_aucl_2 = r * np.sin(Theta_grid_aucl_2) * np.cos(Phi_grid_aucl_2)
        y_fine_aucl_2 = r * np.sin(Theta_grid_aucl_2) * np.sin(Phi_grid_aucl_2)
        z_fine_aucl_2 = r * np.cos(Theta_grid_aucl_2)

        cmap_set = sns.color_palette('gnuplot', as_cmap=True)
        
        norm_aucl_2 = plt.Normalize(a2, b2)
        colors_aucl_2 = cmap_set(norm_aucl_2(Wi_aucl_2))

        ax0.plot_surface(x_fine_aucl_2, y_fine_aucl_2, z_fine_aucl_2, facecolors=colors_aucl_2, 
                         rstride=1, cstride=1, linewidth=0, antialiased=False, shade=False)

mappable = plt.cm.ScalarMappable(cmap=cmap_set, norm=norm_aucl_2)
mappable.set_array(Wi_aucl_2)
color_bar = fig.colorbar(mappable, cax=axc0, orientation='vertical', 
                         ticks=[-1,-2,-3,-4], extend="both")
color_bar.ax.tick_params(labelsize=Ft)
color_bar.set_ticklabels([1.1,1.01,1.001,1.0001])
#color_bar.set_label('$\\alpha_{CR}$', fontsize=Fl)

for j in [1,0]:
    for k in [-1,1]:
        Phi_aucl = np.linspace(min(phi_aucl), max(phi_aucl), 200)*k
        Theta_aucl = np.linspace(min(theta_aucl), max(theta_aucl), 200) + j * pi
        Phi_grid_aucl, Theta_grid_aucl = np.meshgrid(Phi_aucl, Theta_aucl)
               
        Wi_aucl = griddata((phi_aucl * k, theta_aucl + j * pi), n_coef_aucl, (Phi_grid_aucl, Theta_grid_aucl), method='cubic')
    
        r = 1
        x_fine_aucl = r * np.sin(Theta_grid_aucl) * np.cos(Phi_grid_aucl)
        y_fine_aucl = r * np.sin(Theta_grid_aucl) * np.sin(Phi_grid_aucl)
        z_fine_aucl = r * np.cos(Theta_grid_aucl)

        cmap_set = sns.color_palette('gnuplot', as_cmap=True)
        
        norm_aucl = plt.Normalize(a2, b2)
        colors_aucl = cmap_set(norm_aucl(Wi_aucl))

        ax1.plot_surface(x_fine_aucl, y_fine_aucl, z_fine_aucl, facecolors=colors_aucl, 
                         rstride=1, cstride=1, linewidth=0, antialiased=False, shade=False)

mappable = plt.cm.ScalarMappable(cmap=cmap_set, norm=norm_aucl)
mappable.set_array(Wi_aucl)
color_bar = fig.colorbar(mappable, cax=axc1, orientation='vertical', 
                         ticks=[-1,-2,-3,-4], extend="both")
color_bar.ax.tick_params(labelsize=Ft)
color_bar.set_label('$\\alpha_{CR}$', fontsize=Fl)
color_bar.set_ticklabels([1.1,1.01,1.001,1.0001])
  # \\alpha  |\\bar{J}_{-i}/\\bar{J}_{i}|
for ax in [ax2,ax3]:      

# Dibujar los quivers en ax2
    ax.quiver(1.0, 0, 0, 0.3, 0, 0, color="black", lw=6, arrow_length_ratio=0.4, zorder=5)
    ax.quiver(0, 1, 0, 0, 1.1, 0, color="black", lw=6, arrow_length_ratio=0.2, zorder=6)
    ax.quiver(np.cos(138*pi/180), 0, np.sin(138*pi/180), 
              np.cos(138*pi/180)*0.1**0.5, 0, np.sin(138*pi/180)*0.1**0.5, 
              color="black", lw=6, arrow_length_ratio=0.4, zorder=7)
    ax.text(1.25, 0, 0.125, '$\\vec{a}$', color='black', fontsize=Fl+4)
    ax.text(0, 2, 0.125, '$\\vec{b}$', color='black', fontsize=Fl+4)
    ax.text(np.cos(138*pi/180)*0.75**0.5, 0, 
            np.sin(138*pi/180)*0.75**0.5+0.3, '$\\vec{c}$', 
            color='black', fontsize=Fl+4)

for ax in [ax0,ax1,ax2,ax3]:
    ax.set_aspect('equal')
    ax.set_xlim([-1.2, 1.2])
    ax.set_ylim([-1.2, 1.2])
    ax.set_zlim([-1.2, 1.2])
    ax.grid(False)
    ax.axis('off')
    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    ax.xaxis.set_ticks([])
    ax.yaxis.set_ticks([])
    ax.zaxis.set_ticks([])
    ax.get_proj = lambda: np.dot(Axes3D.get_proj(ax), np.diag([1.5, 1.5, 1.5, 1]))
    ax.set_aspect('equal')
    ax.view_init(25, 67.5)
    
sample_file_name = "fig4.png"
fig.savefig(os.path.join(results_dir, sample_file_name), format="png", dpi=300, bbox_inches='tight')
plt.show()

