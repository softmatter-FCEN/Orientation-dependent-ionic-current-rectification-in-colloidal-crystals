# -*- coding: utf-8 -*-
"""
Created on Fri Sep  6 14:13:55 2024

@author: Santiago
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
import matplotlib.ticker
import seaborn as sns
class OOMFormatter(matplotlib.ticker.ScalarFormatter):
    def __init__(self, order=0, fformat="%1.1f", offset=True, mathText=True):
        self.oom = order
        self.fformat = fformat
        matplotlib.ticker.ScalarFormatter.__init__(self,useOffset=offset,useMathText=mathText)
    def _set_order_of_magnitude(self):
        self.orderOfMagnitude = self.oom
    def _set_format(self, vmin=None, vmax=None):
        self.format = self.fformat
        if self._useMathText:
            self.format = r'$\mathdefault{%s}$' % self.format
import matplotlib.gridspec as gridspec
import os
plt.rcParams["mathtext.fontset"]='dejavuserif'

#%%
data_curves = pd.read_excel('../data/datos.xlsx', skiprows=1, engine='openpyxl')
h = (data_curves[data_curves.columns[0]]).to_numpy()
J_neg_Q = (data_curves[data_curves.columns[1]]).to_numpy()*1e12
J_pos_Q = (data_curves[data_curves.columns[2]]).to_numpy()*1e12
J_neg_rho = (data_curves[data_curves.columns[3]]).to_numpy()*1e12
J_pos_rho = (data_curves[data_curves.columns[4]]).to_numpy()*1e12
aL = (data_curves[data_curves.columns[5]]).to_numpy()
J_neg_aL = (data_curves[data_curves.columns[6]]).to_numpy()*1e12
J_pos_aL = (data_curves[data_curves.columns[7]]).to_numpy()*1e12

# Calcular el coeficiente n_coef
def n_coef(Jneg,Jpos):
    n_coef = np.empty(len(Jpos))
    for i in range(len(Jpos)):
            n_coef[i] = abs(Jneg[i] / Jpos[i])
    return n_coef
n_Q = n_coef(J_neg_Q,J_pos_Q); n_rho = n_coef(J_neg_rho,J_pos_rho)      
n_aL = n_coef(J_neg_aL,J_pos_aL)

sns.color_palette("colorblind")
sns.set_style("ticks")
sns.set_context("paper")
sns.set(rc={'axes.facecolor':'white', 'figure.facecolor':'white', 
            'axes.edgecolor':'black', 'xtick.bottom': True,'ytick.left': True})
results_dir =  "../fig/."

Fl =30; Ft = 24
fig = plt.figure(dpi=300,figsize=[9, 9], constrained_layout=True)

gs_a = gridspec.GridSpec(2, 1, top=1, hspace=0.28, wspace=0)

ax0 = fig.add_subplot(gs_a[1,:])
ax1 = fig.add_subplot(gs_a[0,:])
axes = [ax1,ax0]
ax0.text(-0.2, 0.925, 'b', transform = ax0.transAxes, size = Fl+4, font='arial')
ax0.text(-0.2, 0.925, 'a', transform = ax1.transAxes, size = Fl+4, font='arial')

ax0.plot(h[0:4],n_Q[0:4],'o:',c="tab:blue",markersize=16,lw = 3,zorder=11)
#ax0.plot(np.delete(h,[-2])[0:4],np.delete(n_rho,[-2])[0:4],'v:',c="tab:orange",markersize=16,label="fixed $\\rho$",lw = 3,zorder=10)
ax0.axvline(4*3**0.5 - 5, ls='--', c='darkgray',zorder=-1, lw=2) #solapan nubes
#ax0.axvline((4*3**0.5 - 5)*2, ls='--', c='darkgray',zorder=-1) #solapa nube/NP
ax0.set_xlabel(r"$H\ (\text{nm})$",fontsize=Fl)
ax0.set_ylabel(r"$\alpha_{CR}$",fontsize=Fl)
ax0.set_xticks(np.arange(0,5,1))
ax0.set_yticks(np.arange(1,3,0.2))
#ax0.legend(fontsize=Ft-3,loc='upper left')
ax0.set_xlim(xmin=0.35,xmax=2.1)
ax0.set_xticks([0.5,1.0,1.5,2.0])
ax0.set_ylim(ymin=1.3,ymax=2.)

ax1.plot(aL,n_aL,'o:',c="tab:red",markersize=16,lw = 3,zorder=11)
ax1.axvline((5+1.5)*8/3**0.5, ls='--', c='darkgray',zorder=-1, lw=2) #solapan nubes
ax1.set_xlabel(r"$a_L\ (\text{nm})$",fontsize=Fl)
ax1.set_ylabel(r"$\alpha_{CR}$",fontsize=Fl)
ax1.set_xticks(np.arange(30,55,5))
ax1.set_yticks(np.arange(1.3,2.1,0.2))
#ax1.legend(fontsize=Ft-3,loc='upper left')
ax1.set_xlim(xmin=28,xmax=52)
ax1.set_ylim(ymin=1.3,ymax=1.91)

for ax in axes:
    ax.tick_params(axis='y', labelsize=Ft, pad=10)
    ax.tick_params(axis='x', labelsize=Ft, pad=10)
    ax.tick_params(axis='y', which='both', direction='in', length=12, left=True)
    ax.tick_params(axis='x', which='both', direction='in', length=12, bottom=True)
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.tick_params(which='minor', length=8, color='k')
    
sample_file_name = "fig5.png"
fig.savefig(os.path.join(results_dir, sample_file_name), format="png", dpi=300, bbox_inches='tight')
plt.show()
plt.close("all")