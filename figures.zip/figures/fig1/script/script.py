
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 28 11:37:11 2024

@author: Santiago
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)
import matplotlib.ticker
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D
import os; import re
from mpl_toolkits.axes_grid1 import make_axes_locatable
from scipy.interpolate import griddata
import matplotlib.gridspec as gridspec

plt.rcParams["mathtext.fontset"]='dejavuserif'
#%%
data_curves = pd.read_excel('../data/data_JE.xlsx', skiprows=0, engine='openpyxl')
E = (data_curves[data_curves.columns[0]]).to_numpy()
J_E111 = (data_curves[data_curves.columns[1]]).to_numpy()*1e12
J_E001 = (data_curves[data_curves.columns[2]]).to_numpy()*1e12
E_RECTA = (data_curves[data_curves.columns[3]]).to_numpy()
J_RECTA = (data_curves[data_curves.columns[4]]).to_numpy()*1e12


pi = math.pi

data_map = pd.read_excel('../data/data_blenda_aL32_rho1_5.xlsx', engine='openpyxl')
phi = data_map[data_map.columns[1]].to_numpy()*pi
theta = data_map[data_map.columns[2]].to_numpy()*pi
Jpos = data_map[data_map.columns[7]].to_numpy()
Jneg = data_map[data_map.columns[3]].to_numpy()

# Calcular el coeficiente n_coef
n_coef = np.empty(len(Jpos))
for i in range(len(Jpos)):
        n_coef[i] = abs(Jneg[i] / Jpos[i])

a = 1.00; b = 1.70; Fl =36; Ft = 32

sns.color_palette("colorblind")
sns.set_style("ticks")
sns.set_context("paper")
sns.set(rc={'axes.facecolor':'white', 'figure.facecolor':'white', 
            'axes.edgecolor':'black', 'xtick.bottom': True,'ytick.left': True})
results_dir =  "../fig/."

fig = plt.figure(dpi=300,figsize=[10, 18], constrained_layout=True)

gs_a = gridspec.GridSpec(3, 1, top=1, hspace=0.2, wspace=0.25, height_ratios=[60,100,5])
gs_b = gridspec.GridSpec(3, 1, bottom=0.2, hspace=0, height_ratios=[100,100,5])

ax0 = fig.add_subplot(gs_a[0,:])
ax1 = fig.add_subplot(gs_a[1, :], projection='3d')
axc = fig.add_subplot(gs_b[2,:])





#ax0.text(-0.15, 0.925, 'a)', transform = ax0.transAxes, size = Fl+2, style='italic')
#ax0.text(-0.15, -0.25, 'b)', transform = ax0.transAxes, size = Fl+2, style='italic')

ax0.plot(E,J_E111,'-o',c="tab:blue",markersize=12,label="$\mathbf{E^{ext}}$ || $[111]$",lw = 4,zorder=11)
ax0.plot(E,J_E001,'-o',c="tab:orange",markersize=12,label="$\mathbf{E^{ext}}$ || $[001]$",lw = 4,zorder=10)
ax0.plot(E_RECTA,J_RECTA,linestyle=(0, (1, 2)),c="black", linewidth=3)

ax0.set_xlabel(r"$E^{\text{ext}}\ \text{(V/nm)}$",fontsize=Fl)
ax0.set_ylabel(r"$\bar{j}\ (\text{pA}/\text{nm}^2)$",fontsize=Fl)
ax0.set_xticks(np.arange(-0.3,0.3,0.1))
ax0.set_yticks(np.arange(-30,32,10))
ax0.legend(fontsize=Ft-3,loc='upper left')
ax0.axhline(y=0,ls='--',c='darkgray',lw=2)
ax0.axvline(x=0,ls='--',c='darkgray',lw=2)

ax0.set_xlim(xmin=-0.225,xmax=0.225)
ax0.set_ylim(ymin=-32.5,ymax=32.5)
ax0.tick_params(labelsize = Ft, direction='in', length = 15, pad=10)
ax0.yaxis.set_ticks_position('both')  # Marcas en ambos lados del eje Y
ax0.xaxis.set_ticks_position('both')  # Marcas en ambos lados del eje X
ax0.tick_params(axis='y', which='both', labelleft=True, labelright=False)  # Etiquetas a la izquierda, marcas a ambos lados
ax0.tick_params(axis='x', which='both', labelbottom=True, labeltop=False)  # Etiquetas abajo, marcas a ambos lados
ax0.tick_params(axis='y', direction='in', length=12, right=True, left=True, labelright=False)
ax0.tick_params(axis='x', direction='in', length=12, top=True, bottom=True, labeltop=False)
ax0.tick_params(axis = 'y', which = 'minor', direction='in', length = 8, right=True, left=True)
ax0.tick_params(axis = 'x', which = 'minor', direction='in', length = 8, top=True, bottom=True)




for j in range(0,2):
    for k in range(-1,4):
        # Definir los límites y el espacio de interpolación
        Phi = np.linspace(min(phi), max(phi), 100)+k*pi/2
        Theta = np.linspace(min(theta), max(theta), 100)+j*pi
        # Crear una malla fina para interpolar
        Phi_grid, Theta_grid = np.meshgrid(Phi, Theta)
               
        # Interpolar los valores de W en la nueva malla
        Wi = griddata((phi+k*pi/2, theta+j*pi), n_coef, (Phi_grid, Theta_grid), method='cubic')
    
        # Convertir a coordenadas cartesianas para la esfera
        r = 1  # Radio de la esfera
        x_fine = r * np.sin(Theta_grid) * np.cos(Phi_grid)
        y_fine = r * np.sin(Theta_grid) * np.sin(Phi_grid)
        z_fine = r * np.cos(Theta_grid)

        # Normalizar Wi para usarlo en la función de color
        norm = plt.Normalize(a, b)
        colors = plt.cm.gnuplot(norm(Wi))

        # Graficar la superficie en la esfera con color basado en Wi
        ax1.plot_surface(x_fine, y_fine, z_fine, facecolors=colors, rstride=1, 
                        cstride=1, linewidth=0, antialiased=False, shade=False)

mappable = plt.cm.ScalarMappable(cmap= plt.cm.gnuplot, norm=norm)
mappable.set_array(Wi)

color_bar = fig.colorbar(mappable, cax=axc, ticks=np.linspace(a,b,8),
                         orientation="horizontal", extend="both")

color_bar.ax.tick_params(labelsize=Ft, rotation=270)
color_bar.set_label('$\\alpha_{CR}$',fontsize=Fl, rotation=270)

kwargs = dict(transform=ax1.transAxes, color='k', clip_on=False)
ax1.xaxis.pane.fill = False
ax1.yaxis.pane.fill = False
ax1.zaxis.pane.fill = False
ax1.xaxis.pane.set_edgecolor('w')
ax1.yaxis.pane.set_edgecolor('w')
ax1.zaxis.pane.set_edgecolor('w')
ax1.quiver(1.0, 0, 0, 0.9, 0, 0, color="black", lw=6,arrow_length_ratio=0.2)
ax1.quiver(0, 1.0, 0, 0, 0.4, 0, color="black", lw=6,arrow_length_ratio=0.4)
ax1.quiver(0, 0, 1.0, 0, 0, 0.3, color="black", lw=6,arrow_length_ratio=0.6)

ax1.axis('off')
ax1.set_xlim([-1.2, 1.2])
ax1.set_ylim([-1.2, 1.2])
ax1.set_zlim([-1.2, 1.2])
ax1.get_proj = lambda: np.dot(Axes3D.get_proj(ax1), np.diag([1.5, 1.5, 1.5, 1]))
for angle in range(0, 360):
    ax1.view_init(25,30)

# Etiquetas de los ejes
ax1.text(1.85, 0, 0.15, '$x$', color='black', fontsize=Fl+4)
ax1.text(0, 1.15, 0.1, '$y$', color='black', fontsize=Fl+4)
ax1.text(0.15, 0.15, 1.2, '$z$', color='black', fontsize=Fl+4)
ax1.set_aspect('equal')
        
sample_file_name = "fig1.png"
fig.savefig(os.path.join(results_dir, sample_file_name), format="png", dpi=300, bbox_inches='tight')
plt.show()
plt.close("all")

#%% surface
X = np.arange(0,max(theta)/pi +0.05,0.05)
Y = np.arange(0,max(phi)/pi +0.05,0.05)
W = n_coef.reshape(len(X), len(Y)).transpose()

fig = plt.figure(dpi=300, figsize=[12, 11], constrained_layout=True)
gs = plt.GridSpec(1, 2, left=0.1, width_ratios=[100,5])
gs_c = plt.GridSpec(1, 2, right=0.85, width_ratios=[100,5])
ax = fig.add_subplot(gs[0, 0])
axc = fig.add_subplot(gs_c[:2, 1])
scatter = ax.contourf(X,Y,W,levels=np.linspace(a,b, 100),cmap="gnuplot",vmin=a,vmax=b,extend='both')

ax.set_xlabel('$\\theta/\pi\ rad$',fontsize=30)
ax.set_ylabel('$\\phi/\pi\ rad$',fontsize=30)
ax.axis('equal')
ax.set_xlim(0,max(theta)/pi); ax.set_ylim(max(phi)/pi,0)
ax.tick_params(axis='y', labelsize=26, pad=10)
ax.tick_params(axis='x', labelsize=26, pad=10)
divider = make_axes_locatable(axc)
color_bar = fig.colorbar(scatter, cax=axc, orientation='vertical', 
                         ticks=np.linspace(a,b,8),extend="both")
color_bar.ax.tick_params(labelsize=30)
color_bar.set_label('$|J_{-i}/J_{i}|$',fontsize=36)
#ax.axhline(np.arccos(1/3**0.5)/pi,ls='--',c='white',lw=2)
#ax.axvline(0.25,ls='--',c='white',lw=2)
ax.tick_params(axis='y', which='both', direction='out', length=12, left=True)
ax.tick_params(axis='x', which='both', direction='out', length=12, bottom=True)
ax.yaxis.set_minor_locator(AutoMinorLocator(2))
ax.xaxis.set_minor_locator(AutoMinorLocator(2))
ax.tick_params(which='minor', length=8, color='k')
ax.set_title('$Blenda\ aL=32$ nm', fontsize=36)